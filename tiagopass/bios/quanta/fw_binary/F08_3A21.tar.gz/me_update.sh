#!/bin/sh

./PreUpdate.sh $1
if [ `echo $?` == "1" ];then 
  exit 1
fi

echo "Update ME..."
./afulnx_64 $1 /ME
