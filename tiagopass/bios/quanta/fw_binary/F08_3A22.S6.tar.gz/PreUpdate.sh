#!/bin/sh

if [ -z $1 ]; then
    echo "No input filename."
    exit 1
fi

#
# Identify platform (TiogaPass) and manufacturer (Quanta).
#
if [ "$2" == "-force" ];then 
  #
  # Skip manufacturer and product name checking if user would like to force update.
  #
  echo "Force update (Skip manufacturer and product name checking)..."

else
  #
  # Check board - manufacturer
  #
  MFG_NAME=`dmidecode | grep Quanta`
  if [ -z "$MFG_NAME" ]; then 
    echo "This board is not manufactured by Quanta..."
    echo "use -force parameter to force update"
    exit 1
  fi

  #
  # Check board - product name (TiogaPass)
  #
  platform=`echo $1| head -c 10 | tail -c 2`
  case "$platform" in
    ".B")
      PRODUCT_NAME=`dmidecode | grep "Tioga Pass"`
      if [ -z "$PRODUCT_NAME" ]; then 
        echo "This board is not TiogaPass..."
        echo "use -force parameter to force update"
        exit 1
      fi
	;;

  esac

fi
